import { AxiosRequestConfig } from 'axios';

export class HttpRequestConfig implements AxiosRequestConfig {}
