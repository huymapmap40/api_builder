# Changelog

All notable changes to this project LoanMods.Automation.Core.LIB will be documented in this file.

## [1.0.0] - 2022-01-15

### Added

-   Added basic function
-   Added function build config param

### Changed

-   Added test config
